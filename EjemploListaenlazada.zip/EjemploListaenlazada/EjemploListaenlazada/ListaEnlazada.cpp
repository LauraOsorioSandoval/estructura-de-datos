#include "ListaEnlazada.h"
ListaEnlazada::ListaEnlazada() {
	primero = NULL;
	ultimo = NULL;
}
ListaEnlazada::~ListaEnlazada() {

}
void ListaEnlazada::agregarAnimal(string nombre, string habitat, string estado) {
	Nodo* nuevo = new Nodo(nombre, habitat, estado);
	if (primero == NULL) {
		primero = ultimo = nuevo;
	}
	else {
		ultimo->sig = nuevo;
		ultimo = nuevo;
	}
	

}
void ListaEnlazada::eliminarAnimal(string nombre) {
	bool enc = false;
	//Si queres eliminar el primero elemento
	if (primero->nombre == nombre) {
		Nodo* temp = primero;
		primero = primero->sig;
		delete temp;
		enc = true;
	}

	//Si no es el primer elemento
	Nodo* aux = primero;
	while (aux!=NULL)
	{
		if (aux->sig->nombre == nombre) {
			enc = true;
			Nodo* temp = aux->sig;
			aux -> sig = aux->sig->sig;
			delete temp;
			cout << "Animal eliminado" << endl;
		}
		else {
			aux = aux->sig;
		}
	}
	if (!enc)
		cout << "Animal no encontrado" << endl;
}
void  ListaEnlazada::buscar(string nombre) {
	Nodo* actual = primero;
	while (actual)
	{
		if (actual->nombre == nombre) {
			cout << "Nombre " << actual->sig;
			cout << "Habitat: " << actual->habitad;
			cout << "Habitat: " << actual->estadoConservacion;
		
		}
		actual = actual->sig;
	}
}
void ListaEnlazada::mostrar() {
	Nodo* actual = primero;
	while (actual)
	{
			cout << "Nombre " << actual->sig;
			cout << "Habitat: " << actual->habitad;
			cout << "Habitat: " << actual->estadoConservacion;
			actual = actual->sig;
	}
}