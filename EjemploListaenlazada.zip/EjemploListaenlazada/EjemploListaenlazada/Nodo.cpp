#include "Nodo.h"
Nodo::Nodo(string n, string h, string e) {
	this->estadoConservacion = e;
	this->habitad = h;
	this->nombre = n;
	sig = NULL;
}
Nodo::Nodo() {
	sig = NULL;

}