#pragma once
#include <iostream>
#include <string>
using namespace std;
class Nodo
{
public: 
	string nombre;
	string habitad;
	string estadoConservacion;
	Nodo *sig;
	Nodo();
	Nodo(string n, string h, string e);
	
};

